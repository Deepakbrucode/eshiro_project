<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct();
		$this->load->model('dashboard_model');
		$this->load->model('client_model');
		$this->load->helper('url');
	}
	public function index(){

		$ClientDetails = $this->client_model->getClientDetails();


		$data = array(
					'view_file'=>'dashboard',
					'current_menu'=>'dashboard',
					'site_title' =>'Accounting Software',
					'logo'		=> 'logo',
					'title'=>'Dashboard',
					'ClientDetails' => $ClientDetails,
					'headerfiles'   => array(
								"css" => array(
									'lib/font-awesome/css/font-awesome.min.css',
									'lib/simple-line-icons/simple-line-icons.min.css',
									'lib/bootstrap/css/bootstrap.min.css',
									'lib/rs-plugin/css/pi.settings.css',
									'lib/select2/css/select2.min.css',
									'lib/select2/css/select2-bootstrap.min.css',
									'css/components.min.css',
									'css/plugins.min.css',
									'css/layout.css',
									'css/themes/blue.css',
									'css/custom.min.css'
									),
								"js" => array(
									'lib/jquery-1.11.0.min.js',
								),
								"priority" => 'high'
								),
					'footerfiles'   => array(
								"js" => array(
									'lib/bootstrap/js/bootstrap.min.js',
									'lib/scripts/app.min.js',
									'lib/scripts/layout.min.js',
									'lib/select2/js/select2.full.min.js',

									),
								"priority" => 'high'
								)
				);

		$this->template->load_admin_template($data);
	}
	public function session_client(){
		$client_id = $this->input->post('client_id');
		$ClientDetails = $this->client_model->getClientDetails(array('client_id' => $client_id));
		if($ClientDetails){

                                                foreach ($ClientDetails as $client) {
                                                	$client_name = $client->firm_name;
                                                	$start_month = $client->financial_month_start;
                                                	$end_month = $client->financial_month_end;

                                                }
                                            }
		$this->session->set_userdata(array(
										'filtered_client_id' => $client_id,
										'filtered_client_name' => $client_name,
										'filtered_start_month' => $start_month,
										'filtered_end_month' => $end_month
								));

		redirect(BASE_URL.'file/index/');

	}
}

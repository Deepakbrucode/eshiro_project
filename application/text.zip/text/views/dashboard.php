            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <i class="icon-home"></i>
                                <a href="#">Dashboard</a>
                            </li>

                        </ul>
                    </div>
                    <!-- END PAGE HEADER-->
                    <div class="row">
                        <div class="col-md-12">
                        <a href="<?php echo BASE_URL; ?>client/add_client" class="btn btn-primary" style="float: right;">Add Client</a>
                            <form action="<?php echo BASE_URL;?>dashboard/session_client" method="post" class="form-horizontal">
                           <!--  <a href="<?php echo BASE_URL; ?>client/add_client" class="btn btn-primary">Add Client</a> -->
                            <div class="form-group">
                                <label for="single" class="col-md-3 control-label">Client</label>
                                <div class="col-md-4">
                                    <select id="select2_client" name="client_id" class="form-control select2" required>
                                        <option></option>
                                        <?php 
                                            if($ClientDetails){
                                                foreach ($ClientDetails as $client) {
                                                    $ccid = $client->client_id;
                                                    if($ccid == $client_id){$selected = 'selected';}else {$selected = '';}
                                                    echo "<option value='".$client->client_id."' ".$selected.">".$client->firm_name."</option>";
                                                }
                                            }
                                        ?>
                                                                    
                                    </select>
                                                                
                                </div>
                                <!-- <div class="col-md-4">
                                    <a class="btn purple btn-outline sbold" data-toggle="modal" href="#modal_addclient"> Add Client </a>
                                </div> -->
                            </div>

                            <div class="col-md-12">
                                <div class="col-md-3"></div>
                                <div class="col-md-4">
                                <center><button type="submit" class="btn btn-success">Select Client</button></center>
                                </div>
                            </div>
                            </form>

                        </div>
                    </div>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->


            <div class="modal fade" id="modal_addclient" tabindex="-1" role="modal_addclient" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                            <center><h4 class="modal-title">Add Client Details</h4></center>
                        </div>
                        <div class="modal-body"> 
                            <div class="error_msg"></div>
                            <form action="#" method="post" class="formadd_client form-horizontal">
                                <div class="form-body">
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Firm Name</label>
                                        <div class="col-md-6">
                                            <input type="text" name="firm_name" class="form-control firm_name" placeholder="Firm Name" value="" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Directors</label>
                                        <div class="col-md-6">
                                            <input type="text" name="directors" class="form-control" placeholder="Directors" value="">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Registered Address</label>
                                        <div class="col-md-6">
                                            <textarea name="registered_address" class="form-control" placeholder="Registered Address"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Physical Address</label>
                                        <div class="col-md-6">
                                            <textarea name="physical_address" class="form-control" placeholder="Physical Address"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Postal Address</label>
                                        <div class="col-md-6">
                                            <textarea name="postal_address" class="form-control" placeholder="Postal Address"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-4 control-label">Bank Accounts</label>
                                        <div class="col-md-6">
                                            <input type="text" class="form-control" name="bank_accounts" placeholder="Bank Accounts" value="">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn dark btn-outline" data-dismiss="modal">Close</button>
                            <button type="button" class="btn green btn_addclient">Add Client</button>
                        </div>
                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
            <!-- /.modal -->


            <script type="text/javascript">
                $(document).ready(function(){
            $('#select2_client').select2({
            placeholder: "Client Name",
            allowClear: true
        });

        $(".btn_addclient").click(function(){
            $(".error_msg").html('');
            var firm_name = jQuery(".firm_name").val();
            var option_html = '';
            src = '<?php echo BASE_URL; ?>'+'client/addclient_ajax';
            if(firm_name != '')
            {
                $.ajax({
                    url: src,
                    type:'POST',
                    dataType: "json",
                    data: $(".formadd_client").serialize(),
                    success: function(data) {

                  if(data)
                  {

                    $("#select2_client").html("");
                     option_html += "<option></option>";
                    $.each(data,function(key, value){

                        option_html += "<option value='"+value['client_id']+"'>"+value['firm_name']+"</option>";
                    })
                  }

                    //console.log(data);
                     $("#select2_client").html(option_html);

                    }
                });
                $('#modal_addclient').modal('hide');
            }
            else
            {
                $(".error_msg").html('<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button><span> Please enter the firm name</span></div>');
            }

        })

       /* function client_name(){
            alert("next function ");
            src = '<?php echo BASE_URL; ?>'+'client/get_clientnames';
            $.ajax({
                url: src,
                type:'POST',
                dataType: "json",
                success: function(data) {
                    console.log(data);

                    $("#select2_client").html();

                   // response(data);

                }
            });
        }*/



})
            </script>
            

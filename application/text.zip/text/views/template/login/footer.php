<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

 <!-- BEGIN FOOTER -->
        <div class="page-footer">
            <div class="page-footer-inner"> 
            </div>
            <!-- END FOOTER -->
            <!-- BEGIN QUICK NAV -->

            </div>
<?php if(isset($footerfiles)){
	echo include_files($footerfiles, 'header');
}
?>

</body>
</html>

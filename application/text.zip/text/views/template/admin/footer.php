<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
    </div>
        <!-- END CONTAINER -->  <!-- container start in sidebar.php -->
 <!-- BEGIN FOOTER -->
        <div class="page-footer">
            <div class="page-footer-inner"> 2017 &copy; Stallioni
            </div>
            <!-- END FOOTER -->
            <!-- BEGIN QUICK NAV -->

            </div>
<?php if(isset($footerfiles)){
	echo include_files($footerfiles, 'header');
}
?>

</body>
</html>

<style type="text/css"> 

    table {
    border-collapse: collapse;
        table-layout: fixed;
    border:0px;
     border: 1px solid #b4b4b4;
     /*width:200px;*/
}

table, td, th {
    font-size: 11px;
   /* border-bottom: 1px solid black!important; */
/*    border:none;*/
}

.col-md-12{width: 100%;}
 td, th {

        border-bottom: 1px solid #b4b4b4;
}

/*.col-md-6{width: 49%;display:inline-block;float: left;}
.col-md-8{    width: 66.66667%; display: inline-block;margin:0px auto;}*/

table {
    table-layout: fixed;
    width: 100%;   

}

      th,td {

    word-wrap: break-word;padding-top:5px;padding-bottom:5px;
}

tr td:first-child{padding-left:10px;}
tr td:last-child {
 padding-right:10px;
}
thead{background-color: #ac9076;color: white;}

 tr td:nth-last-child(1), tr td:nth-last-child(2), tr td:nth-last-child(3) {
text-align:right;
}


 tr:last-child {
font-weight: bold;
}
@page { margin: 90px 50px 0px; }
    #header { position: fixed; left: 0px; top: -80px; right: 0px; height: 100px;/* background-color: orange;*/ text-align: center; }
</style>



         
                        <?php echo $cbd_txt_pdf; ?>
                            
                         



